package com.fansfunding.weibo;

/**
 * Created by 13616 on 2016/7/6.
 */
public class AuthListener {
}
