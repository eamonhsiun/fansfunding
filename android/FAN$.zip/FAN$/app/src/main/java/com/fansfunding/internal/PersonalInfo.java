package com.fansfunding.internal;

import java.util.Date;

/**
 * Created by 13616 on 2016/7/14.
 */
public class PersonalInfo {

    //返回的结果
    private boolean result;

    //返回的状态码
    private int errCode;

    //返回的数据
    private DataDetial data;

    //token
    private String token;

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public int getErrCode() {
        return errCode;
    }

    public void setErrCode(int errCode) {
        this.errCode = errCode;
    }

    public DataDetial getData() {
        return data;
    }

    public void setData(DataDetial data) {
        this.data = data;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }


    public class DataDetial {
        //用户ID
        private int id;

        //用户名
        private String name;

        //用户昵称
        private String nickname;

        //用户密码
        private String password;

        //用户手机号码
        private String phone;

        //是否网红
        private int is_red;

        //头像url
        private String head;

        //email
        private String email;

        //创建者
        private String create_by;

        //创建时间
        private Date create_time;

        //更新者
        private String update_by;

        //更新时间
        private Date update_time;

        //remark
        private String remark;

        //微信的token
        private String token_wx;

        //微博的token
        private String token_wb;

        //qq的token
        private String token_qq;

        //微信的id
        private int id_wx;
        //微博的id
        private int id_wb;

        //qq的id
        private int id_qq;
        //token
        private int token;


        private RealInfo realInfo;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getNickname() {
            return nickname;
        }

        public void setNickname(String nickname) {
            this.nickname = nickname;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public int getIs_red() {
            return is_red;
        }

        public void setIs_red(int is_red) {
            this.is_red = is_red;
        }

        public String getHead() {
            return head;
        }

        public void setHead(String head) {
            this.head = head;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getCreate_by() {
            return create_by;
        }

        public void setCreate_by(String create_by) {
            this.create_by = create_by;
        }

        public Date getCreate_time() {
            return create_time;
        }

        public void setCreate_time(Date create_time) {
            this.create_time = create_time;
        }

        public String getUpdate_by() {
            return update_by;
        }

        public void setUpdate_by(String update_by) {
            this.update_by = update_by;
        }

        public Date getUpdate_time() {
            return update_time;
        }

        public void setUpdate_time(Date update_time) {
            this.update_time = update_time;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getToken_wx() {
            return token_wx;
        }

        public void setToken_wx(String token_wx) {
            this.token_wx = token_wx;
        }

        public String getToken_wb() {
            return token_wb;
        }

        public void setToken_wb(String token_wb) {
            this.token_wb = token_wb;
        }

        public String getToken_qq() {
            return token_qq;
        }

        public void setToken_qq(String token_qq) {
            this.token_qq = token_qq;
        }

        public int getToken() {
            return token;
        }

        public void setToken(int token) {
            this.token = token;
        }

        public RealInfo getRealInfo() {
            return realInfo;
        }

        public void setRealInfo(RealInfo realInfo) {
            this.realInfo = realInfo;
        }

        public int getId_wx() {
            return id_wx;
        }

        public void setId_wx(int id_wx) {
            this.id_wx = id_wx;
        }

        public int getId_wb() {
            return id_wb;
        }

        public void setId_wb(int id_wb) {
            this.id_wb = id_wb;
        }

        public int getId_qq() {
            return id_qq;
        }

        public void setId_qq(int id_qq) {
            this.id_qq = id_qq;
        }


        public class RealInfo{
            //用户id
            private int userId;

            //真实姓名
            private String realName;

            //性别
            private byte sex;

            //身份证
            private String idNumber;

            //出生地
            private String birthPlace;

            //出生日期
            private Date birthday;

            //地址
            private String address;

            //
            private int isValidated;

            public int getUserId() {
                return userId;
            }

            public void setUserId(int userId) {
                this.userId = userId;
            }

            public String getRealName() {
                return realName;
            }

            public void setRealName(String realName) {
                this.realName = realName;
            }

            public byte getSex() {
                return sex;
            }

            public void setSex(byte sex) {
                this.sex = sex;
            }

            public String getIdNumber() {
                return idNumber;
            }

            public void setIdNumber(String idNumber) {
                this.idNumber = idNumber;
            }

            public String getBirthPlace() {
                return birthPlace;
            }

            public void setBirthPlace(String birthPlace) {
                this.birthPlace = birthPlace;
            }

            public Date getBirthday() {
                return birthday;
            }

            public void setBirthday(Date birthday) {
                this.birthday = birthday;
            }

            public String getAddress() {
                return address;
            }

            public void setAddress(String address) {
                this.address = address;
            }

            public int getIsValidated() {
                return isValidated;
            }

            public void setIsValidated(int isValidated) {
                this.isValidated = isValidated;
            }
        }

    }
}
