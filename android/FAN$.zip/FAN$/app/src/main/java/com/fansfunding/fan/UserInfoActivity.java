package com.fansfunding.fan;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.design.widget.TabLayout;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.fansfunding.internal.ErrorCode;
import com.fansfunding.internal.PersonalInfo;
import com.fansfunding.internal.UpLoadHead;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.io.File;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class UserInfoActivity extends AppCompatActivity {


    private static final int PHOTO_REQUEST_CAMERA = 1001;// 拍照
    private static final int PHOTO_REQUEST_GALLERY = 1002;// 从相册中选择
    private static final int PHOTO_REQUEST_CUT = 1003;// 结果

    //获取用户信息成功
    private static final int GET_USER_INFO_SUCCESS=100;

    //获取用户信息失败
    private static final int GET_USER_INFO_FAILURE=101;

    //上传头像失败
    private static final int SEND_USER_HEAD_FAILURE=102;

    //上传头像成功
    private static final int SEND_USER_HEAD_SUCCESS=103;

    //上传用户信息失败
    private static final int SEND_USER_INFO_FAILURE=104;

    //上传用户信息成功
    private static final int SEND_USER_INFO_SUCCESS=105;


    //设置相机所获取的照片的名字
    private static final String PHOTO_FILE_NAME = "temp_head_photo.jpg";

    //spinner的数据源
    private static final String[] sexString={"女","男"};

    //httpclient
    OkHttpClient httpClient;


    //用来存储修改后头像的文件
    private File tempFile;

    //头像的bitmap
    private Bitmap bitmap;

    //性别
    private int sex;

    //循环等待框，不能取消
    AlertDialog dialog_waitting;

    //选择头像来源的弹出框
    AlertDialog dialog_user_head_source;


    //头像控件
    private ImageView iv_user_info_head;
    //昵称输入栏
    private TextInputEditText tiet_user_info_nickname;
    //性别选择框
    private Spinner spinner;
    //邮箱输入栏
    private TextInputEditText tiet_user_info_email;

    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch(msg.what){
                //获取用户信息失败
                case GET_USER_INFO_FAILURE:
                    if(UserInfoActivity.this.isFinishing()==true)
                        break;
                    Toast.makeText(UserInfoActivity.this,"获取信息失败，请按头像重试",Toast.LENGTH_LONG).show();
                    break;
                //获取用户信息成功
                case GET_USER_INFO_SUCCESS:
                    if(UserInfoActivity.this.isFinishing()==true)
                        break;
                    InitUserInfo();
                    if(dialog_waitting.isShowing()==true){
                        dialog_waitting.cancel();
                    }
                    break;
                //上传用户头像失败
                case SEND_USER_HEAD_FAILURE:
                    break;
                //上传用户头像成功
                case SEND_USER_HEAD_SUCCESS:
                    break;
                //上传用户信息失败
                case SEND_USER_INFO_FAILURE:
                    break;
                //上传用户信息成功
                case SEND_USER_INFO_SUCCESS:
                    break;
                default:
                    super.handleMessage(msg);
                    break;
            }

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar_user_info);
        setSupportActionBar(toolbar);
        Intent intent=getIntent();

        toolbar.setTitleTextColor(Color.WHITE);
        toolbar.setBackgroundColor(Color.RED);
        //设置返回键
        ActionBar actionBar=this.getSupportActionBar();
        actionBar.setTitle("编辑个人信息");
        actionBar.setDisplayHomeAsUpEnabled(true);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,sexString);

        //设置性别选择框
        spinner=(Spinner)findViewById(R.id.spinner_user_info_sex);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sex=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinner.setVisibility(View.VISIBLE);
        spinner.setPrompt("性别");



        //获取并设置修改头像按钮
        Button btn_user_info_head_change=(Button)findViewById(R.id.btn_user_info_head_change);
        btn_user_info_head_change.setOnClickListener(new ChangeHeadListener());

        getUserInfo();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        switch (id){
            case android.R.id.home:
                finish();
                break;
            case R.id.menu_user_info_finish:
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_user_info, menu);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch(requestCode){
            case PHOTO_REQUEST_GALLERY:
                if (data != null) {
                    // 得到图片的全路径
                    Uri uri = data.getData();
                    crop(uri);

                    String[] proj = { MediaStore.Images.Media.DATA };
                    Cursor actualimagecursor = managedQuery(uri,proj,null,null,null);
                    int actual_image_column_index = actualimagecursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                    actualimagecursor.moveToFirst();
                    String img_path = actualimagecursor.getString(actual_image_column_index);
                    tempFile=new File(img_path);
                }
                break;
            case PHOTO_REQUEST_CAMERA:
                if (hasSdcard()) {
                    tempFile = new File(Environment.getExternalStorageDirectory(),
                            PHOTO_FILE_NAME);
                    crop(Uri.fromFile(tempFile));
                } else {
                    Toast.makeText(UserInfoActivity.this, "未找到存储卡，无法存储照片！", Toast.LENGTH_LONG).show();
                }
                break;

            case PHOTO_REQUEST_CUT:
                if(data==null) {
                    break;
                }
                bitmap = data.getParcelableExtra("data");
                this.iv_user_info_head.setImageBitmap(bitmap);

                break;
            default:
                super.onActivityResult(requestCode, resultCode, data);
        }

    }


    private void UploadUserInfo(){
        //循环等待框
        dialog_waitting=new AlertDialog.Builder(this)
                .setTitle("数据传输")
                .setView(R.layout.activity_internal_waiting)
                .create();
        dialog_waitting.setCancelable(false);
        dialog_waitting.show();

        if(tempFile!=null){

        }

        //获得昵称
        String nickname=tiet_user_info_nickname.getText().toString();
        //获得性别(为全局变量)

        //获取email地址
        String email=tiet_user_info_email.getText().toString();



    }

    private void UploadUserHead(){
        //获取用户id
        SharedPreferences share=getSharedPreferences(getString(R.string.sharepreference_login_by_phone), MODE_PRIVATE);
        int userId=share.getInt("id",0);

        RequestBody requestBodyTest= FormBody.create(MediaType.parse("image/jpeg"),tempFile);
        RequestBody requestBody=new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", tempFile.getName(),requestBodyTest)
                .build();
        Request request=new Request.Builder()
                .post(requestBody)
                .url(getString(R.string.url_user)+userId+"/head")
                .build();
        Call call=httpClient.newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Message msg=new Message();
                msg.what=SEND_USER_HEAD_FAILURE;
                handler.sendMessage(msg);
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //服务器响应失败
                if(response==null||response.isSuccessful()==false){
                    Message msg=new Message();
                    msg.what=SEND_USER_HEAD_FAILURE;
                    handler.sendMessage(msg);
                    return;
                }
                Gson gson=new GsonBuilder().create();
                UpLoadHead uploadHead=new UpLoadHead();
                String str_response=response.body().string();
                try {

                    //用Gson进行解析，并判断结果是否为空
                    if((uploadHead = gson.fromJson(str_response, uploadHead.getClass()))==null){
                        Message msg=new Message();
                        msg.what=SEND_USER_HEAD_FAILURE;
                        handler.sendMessage(msg);
                        return;
                    }
                    //处理登陆失败
                    if(uploadHead.isResult()==false){
                        Message msg=new Message();
                        switch (uploadHead.getErrCode()){
                            case ErrorCode.REQUEST_TOO_FRENQUENTLY:
                                msg.what=ErrorCode.REQUEST_TOO_FRENQUENTLY;
                                break;
                            case ErrorCode.PARAMETER_ERROR:
                                msg.what=ErrorCode.PARAMETER_ERROR;
                                break;
                            case ErrorCode.AUTHORITY_NOT_ENOUGH:
                                msg.what=ErrorCode.AUTHORITY_NOT_ENOUGH;
                                break;
                            default:
                                msg.what=SEND_USER_HEAD_FAILURE;
                                break;
                        }
                        handler.sendMessage(msg);
                        return;
                    }
                    //将验证码信息保存到SharePreference里
                    SharedPreferences share=getSharedPreferences(getString(R.string.sharepreference_upload_head),MODE_PRIVATE);
                    SharedPreferences.Editor editor=share.edit();

                    editor.commit();



                    //登陆成功
                    Message msg=new Message();
                    msg.what=SEND_USER_HEAD_SUCCESS;
                    handler.sendMessage(msg);

                }catch (IllegalStateException e){
                    Message msg=new Message();
                    msg.what=SEND_USER_HEAD_FAILURE;
                    handler.sendMessage(msg);
                    e.printStackTrace();
                }catch (JsonSyntaxException e){
                    Message msg=new Message();
                    msg.what=SEND_USER_HEAD_FAILURE;
                    handler.sendMessage(msg);
                    e.printStackTrace();
                }

            }
        });
    }

    //在获取到用户信息后初始化
    private void InitUserInfo(){

        SharedPreferences share=getSharedPreferences(getString(R.string.sharepreference_user_info),MODE_PRIVATE);
        //昵称
        String nickname=share.getString("nickname","");
        //性别，默认为女，0为女，1为男
        sex=share.getInt("sex",0);
        //邮箱
        String email= share.getString("email","");
        //头像url
        String url_head=share.getString("head","");

        //用户昵称初始化
        tiet_user_info_nickname=(TextInputEditText)findViewById(R.id.tiet_user_info_nickname);
        tiet_user_info_nickname.setText(nickname);

        //用户性别初始化
        spinner.setSelection(sex);

        //用户邮箱初始化
        tiet_user_info_email=(TextInputEditText)findViewById(R.id.tiet_user_info_email);
        tiet_user_info_email.setText(email);

        //获取头像控件并设置
        iv_user_info_head=(ImageView)findViewById(R.id.iv_user_info_head);
        if(url_head.equals("")==false){
            Picasso.with(this).load(url_head).into(iv_user_info_head);
        }
    }

    private void getUserInfo(){
        //循环等待框
        dialog_waitting=new AlertDialog.Builder(this)
                .setTitle("数据传输")
                .setView(R.layout.activity_internal_waiting)
                .create();
        dialog_waitting.setCancelable(false);
        dialog_waitting.show();

        OkHttpClient httpClient=new OkHttpClient();
        SharedPreferences share=getSharedPreferences(getString(R.string.sharepreference_login_by_phone), Context.MODE_PRIVATE);
        int userId=share.getInt("id",0);
        String token=share.getString("token","token");
        Request request=new Request.Builder()
                .url(getString(R.string.url_user)+userId+"/info"+"?token="+token)
                //.addHeader("token",token)
                .get()
                .build();
        System.out.println(userId);
        System.out.println(token);
        Call call=httpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Message msg=new Message();
                msg.what=GET_USER_INFO_FAILURE;
                handler.sendMessage(msg);
                System.out.println("0");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //服务器响应失败
                if(response==null||response.isSuccessful()==false){
                    Message msg=new Message();
                    msg.what=GET_USER_INFO_FAILURE;
                    handler.sendMessage(msg);
                    System.out.println("1");
                    return;
                }

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
                PersonalInfo personalInfo=new PersonalInfo();
                String str_response=response.body().string();
                try {
                    //用Gson进行解析，并判断结果是否为空
                    if((personalInfo = gson.fromJson(str_response, personalInfo.getClass()))==null){
                        Message msg = new Message();
                        msg.what = GET_USER_INFO_FAILURE;
                        handler.sendMessage(msg);
                        System.out.println("2");
                        return;
                    }
                    //处理获取个人信息失败
                    if(personalInfo.isResult()==false){
                        Message msg=new Message();
                        switch (personalInfo.getErrCode()){
                            case ErrorCode.REQUEST_TOO_FRENQUENTLY:
                                msg.what=ErrorCode.REQUEST_TOO_FRENQUENTLY;
                                break;
                            case ErrorCode.PARAMETER_ERROR:
                                msg.what=ErrorCode.PARAMETER_ERROR;
                                break;
                            case ErrorCode.AUTHORITY_NOT_ENOUGH:
                                msg.what=ErrorCode.AUTHORITY_NOT_ENOUGH;
                                break;
                            default:
                                msg.what=GET_USER_INFO_FAILURE;
                                break;
                        }
                        handler.sendMessage(msg);
                        return;
                    }
                    //将验证码信息保存到SharePreference里
                    SharedPreferences share=UserInfoActivity.this.getSharedPreferences(getString(R.string.sharepreference_user_info),MODE_PRIVATE);
                    SharedPreferences.Editor editor=share.edit();
                    editor.putBoolean("result",personalInfo.isResult());
                    editor.putInt("errCode",personalInfo.getErrCode());
                    if(personalInfo.getData()!=null) {
                        editor.putInt("id", personalInfo.getData().getId());
                        editor.putString("name", personalInfo.getData().getName());
                        editor.putString("nickname", personalInfo.getData().getNickname());
                        editor.putString("password", personalInfo.getData().getPassword());
                        editor.putString("phone", personalInfo.getData().getPhone());
                        editor.putString("head", personalInfo.getData().getHead());
                        editor.putString("email", personalInfo.getData().getEmail());
                        editor.putString("token_wx", personalInfo.getData().getToken_wx());
                        editor.putString("token_wb", personalInfo.getData().getToken_wb());
                        editor.putString("token_qq", personalInfo.getData().getToken_qq());
                        editor.putInt("id_wx", personalInfo.getData().getId_wx());
                        editor.putInt("id_wb", personalInfo.getData().getId_wb());
                        editor.putInt("id_qq", personalInfo.getData().getId_qq());
                        editor.putString("token", personalInfo.getToken());
                        editor.putInt("is_red", personalInfo.getData().getIs_red());

                        if (personalInfo.getData().getRealInfo() != null) {
                            editor.putString("readInfo_idNumber", personalInfo.getData().getRealInfo().getIdNumber());
                            editor.putInt("readInfo_userId", personalInfo.getData().getRealInfo().getUserId());
                            editor.putInt("readInfo_sex", personalInfo.getData().getRealInfo().getSex());
                            editor.putString("readInfo_realName", personalInfo.getData().getRealInfo().getRealName());
                            editor.putString("readInfo_birthPlace", personalInfo.getData().getRealInfo().getBirthPlace());
                            editor.putLong("readInfo_birthday", personalInfo.getData().getRealInfo().getBirthday().getTime());
                            editor.putString("readInfo_address", personalInfo.getData().getRealInfo().getAddress());
                        }
                    }
                    editor.commit();
                    System.out.println(personalInfo.getData().getHead());
                    //获取信息成功
                    Message msg=new Message();
                    msg.what=GET_USER_INFO_SUCCESS;
                    handler.sendMessage(msg);
                }catch (IllegalStateException e){
                    Message msg=new Message();
                    msg.what=GET_USER_INFO_FAILURE;
                    handler.sendMessage(msg);
                    e.printStackTrace();
                }catch (JsonSyntaxException e){
                    Message msg=new Message();
                    msg.what=GET_USER_INFO_FAILURE;
                    handler.sendMessage(msg);
                    e.printStackTrace();
                }


            }
        });
    }




    //修改头像按钮响应函数
    private class ChangeHeadListener implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            View view_source=View.inflate(UserInfoActivity.this,R.layout.dialog_user_info_head_source,null);

            //从相机获取头像
            final TextView tv_user_info_head_from_camera=(TextView)view_source.findViewById(R.id.tv_user_info_head_from_camera);

            tv_user_info_head_from_camera.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //取消弹出框
                    if(dialog_user_head_source.isShowing()==true){
                        dialog_user_head_source.cancel();
                    }
                    Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                    // 判断存储卡是否可以用，可用进行存储
                    if (hasSdcard()) {
                        intent.putExtra(MediaStore.EXTRA_OUTPUT,
                                Uri.fromFile(new File(Environment
                                        .getExternalStorageDirectory(), PHOTO_FILE_NAME)));
                    }
                    startActivityForResult(intent, PHOTO_REQUEST_CAMERA);

                }
            });

            //从相册获取头像
            TextView tv_user_info_head_from_photo=(TextView)view_source.findViewById(R.id.tv_user_info_head_from_photo);
            tv_user_info_head_from_photo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //取消弹出框
                    if(dialog_user_head_source.isShowing()==true){
                        dialog_user_head_source.cancel();
                    }
                    // 激活系统图库，选择一张图片
                    Intent intent = new Intent(Intent.ACTION_PICK);
                    intent.setType("image/jpeg,image/jpg");
                    startActivityForResult(intent, PHOTO_REQUEST_GALLERY);
                }
            });

            dialog_user_head_source=new AlertDialog.Builder(UserInfoActivity.this)
                    .setTitle("选择头像")
                    .setView(view_source)
                    .create();
            dialog_user_head_source.show();
        }
    }

    //判断呢是否有sd卡
    private boolean hasSdcard() {
        if (Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 剪切图片
     * @param uri
     */
    private void crop(Uri uri) {
        // 裁剪图片意图
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        // 裁剪框的比例，1：1
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // 裁剪后输出图片的尺寸大小
        intent.putExtra("outputX", 250);
        intent.putExtra("outputY", 250);
        // 图片格式
        intent.putExtra("outputFormat", "JPEG");
        intent.putExtra("noFaceDetection", true);// 取消人脸识别
        intent.putExtra("return-data", true);// true:不返回uri，false：返回uri
        startActivityForResult(intent, PHOTO_REQUEST_CUT);
    }

}
